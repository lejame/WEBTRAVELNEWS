package com.example.NewsWebstieJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsWebstieJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsWebstieJavaApplication.class, args);
	}

}
